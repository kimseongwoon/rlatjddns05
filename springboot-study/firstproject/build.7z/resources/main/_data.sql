-- 더미 데이터 생성하기
INSERT INTO article(id, title, content) VALUES(1, '가가가가', '1111');
INSERT INTO article(id, title, content) VALUES(2, '나나나나', '2222');
INSERT INTO article(id, title, content) VALUES(3, '다다다다', '3333');
-- INSERT INTO article(title, content) VALUES('가가가가', '1111');
-- INSERT INTO article(title, content) VALUES('나나나나', '2222');
-- INSERT INTO article(title, content) VALUES('다다다다', '3333');

-- ctrl + / : 주석처리